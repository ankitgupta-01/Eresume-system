from django.apps import AppConfig


class SkillConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'skill'
